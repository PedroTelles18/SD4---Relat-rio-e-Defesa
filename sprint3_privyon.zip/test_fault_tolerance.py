"""
Teste de Tolerância a Falhas - Checkpoint 3
Script de demonstração para a apresentação.

Como usar na apresentação:
  1. Abra 2 terminais
  2. Terminal 1: python server_v3.py        (inicia o servidor)
  3. Terminal 2: python test_fault_tolerance.py  (roda este script)
  4. Durante a execução, vá ao Terminal 1 e pressione Ctrl+C (mata o servidor)
  5. Observe as tentativas de reconexão no Terminal 2
  6. Reinicie o servidor no Terminal 1: python server_v3.py
  7. Observe a reconexão automática no Terminal 2
"""

import socket
import json
import datetime
from datetime import timezone
import time

SERVER_HOST    = '127.0.0.1'
SERVER_PORT    = 9090
RETRY_INTERVAL = 3
TOTAL_REQUESTS = 6   # envia 6 requisições com pausa entre elas


def get_ts() -> str:
    return datetime.datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def send_one(agent_name: str, payload: str) -> dict | None:
    """Envia UMA requisição com reconexão automática em caso de falha."""
    request = {
        "type":             "audit_request",
        "host":             agent_name,
        "payload":          payload,
        "client_timestamp": get_ts()
    }
    message = json.dumps(request, ensure_ascii=False).encode('utf-8')

    attempt = 0
    while True:
        attempt += 1
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(5)
                s.connect((SERVER_HOST, SERVER_PORT))

                if attempt > 1:
                    print(f"    [✓] RECONECTADO após {attempt} tentativas!")

                s.sendall(message)
                raw = s.recv(4096).decode('utf-8')
                response = json.loads(raw)
                return response

        except (ConnectionRefusedError, socket.timeout, OSError):
            if attempt == 1:
                print(f"    [✗] Servidor offline — iniciando reconexão automática...")
            print(f"    [~] Tentativa #{attempt} falhou. Aguardando {RETRY_INTERVAL}s...")
            time.sleep(RETRY_INTERVAL)


def main():
    print("=" * 65)
    print("  TESTE DE TOLERÂNCIA A FALHAS — Privyon v3 — Checkpoint 3")
    print("=" * 65)
    print(f"  Alvo: {SERVER_HOST}:{SERVER_PORT}")
    print(f"  Requisições: {TOTAL_REQUESTS}  |  Retry interval: {RETRY_INTERVAL}s")
    print("=" * 65)
    print()
    print("  >>> Durante a execução, derrube o servidor com Ctrl+C  <<<")
    print("  >>> no terminal do servidor e observe a reconexão!     <<<")
    print()
    time.sleep(2)

    results = []

    for i in range(1, TOTAL_REQUESTS + 1):
        agent   = f"agente-{i:02d}"
        payload = f"heartbeat-{i}"

        print(f"[REQ {i}/{TOTAL_REQUESTS}] {agent} enviando '{payload}'...")
        start = time.time()

        response = send_one(agent, payload)
        elapsed  = int((time.time() - start) * 1000)

        if response and response.get("status") == "ok":
            seq = response.get("seq")
            print(f"  [✓] Seq #{seq} | Tempo total: {elapsed} ms\n")
            results.append({"agent": agent, "seq": seq, "elapsed_ms": elapsed, "status": "ok"})
        else:
            print(f"  [!] Falha na requisição {i}\n")
            results.append({"agent": agent, "seq": None, "elapsed_ms": elapsed, "status": "erro"})

        # Pausa entre requisições — dá tempo de derrubar o servidor na demo
        if i < TOTAL_REQUESTS:
            time.sleep(2)

    # ── Relatório final ──────────────────────────────────────────────
    print()
    print("=" * 65)
    print("  RELATÓRIO FINAL")
    print("=" * 65)
    print(f"  {'Agente':<14} {'Seq':<8} {'Tempo(ms)':<12} {'Status'}")
    print(f"  {'-'*14} {'-'*8} {'-'*12} {'-'*8}")
    for r in results:
        seq_str = f"#{r['seq']}" if r['seq'] else "N/A"
        print(f"  {r['agent']:<14} {seq_str:<8} {r['elapsed_ms']:<12} {r['status']}")

    ok    = sum(1 for r in results if r["status"] == "ok")
    print()
    print(f"  Requisições bem-sucedidas: {ok}/{TOTAL_REQUESTS}")
    print(f"  Tolerância a falhas: {'✅ APROVADO' if ok == TOTAL_REQUESTS else '⚠️  PARCIAL'}")
    print("=" * 65)


if __name__ == "__main__":
    main()
