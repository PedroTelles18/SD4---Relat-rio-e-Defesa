"""
Servidor TCP - Checkpoint 3
Tolerância a Falhas — este servidor é derrubado intencionalmente
durante a apresentação para demonstrar a reconexão automática do cliente.

(Lógica igual ao v2: Lock/Mutex + audit_log)
Para derrubar: Ctrl+C no terminal do servidor.
"""

import socket
import json
import datetime
from datetime import timezone
import threading
import time

HOST = '0.0.0.0'
PORT = 9090

audit_log     = []
audit_counter = 0
resource_lock = threading.Lock()


def get_ts() -> str:
    return datetime.datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def handle_client(conn, addr):
    tid = threading.current_thread().name
    print(f"[+] [{tid}] Conexão de {addr[0]}:{addr[1]}")

    with conn:
        raw = conn.recv(4096).decode('utf-8')
        if not raw:
            return

        try:
            request = json.loads(raw)
        except json.JSONDecodeError as e:
            response = {"type": "error", "status": "error",
                        "message": f"JSON inválido: {str(e)}", "server_timestamp": get_ts()}
            conn.sendall(json.dumps(response).encode('utf-8'))
            return

        host    = request.get('host', '?')
        payload = request.get('payload', '')

        print(f"[>] [{tid}] Recebido de '{host}': payload='{payload}'")
        print(f"[~] [{tid}] Aguardando o Lock...")

        acquired_at = time.time()
        with resource_lock:
            wait_ms = int((time.time() - acquired_at) * 1000)
            print(f"[🔒] [{tid}] Lock ADQUIRIDO (esperou {wait_ms} ms)")

            global audit_counter
            audit_counter += 1
            seq = audit_counter

            time.sleep(0.3)

            entry = {"seq": seq, "host": host, "payload": payload,
                     "thread": tid, "timestamp": get_ts()}
            audit_log.append(entry)
            print(f"[🔓] [{tid}] Lock LIBERADO — seq #{seq} registrado")

        response = {
            "type":             "audit_response",
            "status":           "ok",
            "message":          "Acesso ao recurso crítico concluído com segurança",
            "seq":              seq,
            "echo":             payload,
            "wait_ms":          wait_ms,
            "server_timestamp": get_ts()
        }
        conn.sendall(json.dumps(response, ensure_ascii=False).encode('utf-8'))
        print(f"[<] [{tid}] Resposta enviada → seq=#{seq}\n")


def main():
    print("=" * 60)
    print("  Servidor Privyon v3 - Checkpoint 3 (Tolerância a Falhas)")
    print("  Para simular queda: pressione Ctrl+C")
    print("=" * 60)

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, PORT))
        srv.listen(10)
        print(f"[*] Escutando em {HOST}:{PORT}\n")

        conn_count = 0
        while True:
            conn, addr = srv.accept()
            conn_count += 1
            t = threading.Thread(
                target=handle_client,
                args=(conn, addr),
                name=f"Client-{conn_count:02d}",
                daemon=True
            )
            t.start()


if __name__ == "__main__":
    main()
