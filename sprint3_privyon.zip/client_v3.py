"""
Cliente TCP - Checkpoint 3
Tolerância a Falhas — detecta queda do servidor e tenta reconectar
automaticamente a cada RETRY_INTERVAL segundos.

Uso:
    python client_v3.py                        # envia uma requisição simples
    python client_v3.py meu-host minha-payload # com argumentos
"""

import socket
import json
import datetime
from datetime import timezone
import sys
import time

SERVER_HOST    = '127.0.0.1'
SERVER_PORT    = 9090
RETRY_INTERVAL = 3    # segundos entre tentativas de reconexão
MAX_RETRIES    = 10   # 0 = tenta para sempre


def get_ts() -> str:
    return datetime.datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def send_with_reconnect(host_target: str = "localhost", payload: str = "ping"):
    request = {
        "type":             "audit_request",
        "host":             host_target,
        "payload":          payload,
        "client_timestamp": get_ts()
    }
    message = json.dumps(request, ensure_ascii=False).encode('utf-8')

    attempt = 0
    print("=" * 60)
    print("  Agente Privyon v3 - Checkpoint 3 (Tolerância a Falhas)")
    print("=" * 60)

    while True:
        attempt += 1
        print(f"\n[*] Tentativa #{attempt} — conectando a {SERVER_HOST}:{SERVER_PORT}...")

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(5)                          # timeout de conexão
                s.connect((SERVER_HOST, SERVER_PORT))
                print(f"[✓] Conexão TCP estabelecida na tentativa #{attempt}!")

                s.sendall(message)
                print(f"[>] Enviado: host='{host_target}' payload='{payload}'")

                raw = s.recv(4096).decode('utf-8')
                response = json.loads(raw)

                print("\n[<] Resposta do servidor:")
                print(json.dumps(response, indent=4, ensure_ascii=False))

                if response.get("status") == "ok":
                    print(f"\n[✓] Sucesso! Seq atribuída: #{response.get('seq')}")
                    print(f"    Espera pelo Lock: {response.get('wait_ms')} ms")

                return response   # <<< encerra o loop — missão cumprida

        except (ConnectionRefusedError, socket.timeout, OSError) as e:
            print(f"[✗] Falha na tentativa #{attempt}: {type(e).__name__} — servidor indisponível")

            if MAX_RETRIES > 0 and attempt >= MAX_RETRIES:
                print(f"\n[!] Número máximo de tentativas ({MAX_RETRIES}) atingido. Abortando.")
                return None

            print(f"[~] Aguardando {RETRY_INTERVAL}s antes de tentar novamente...")
            time.sleep(RETRY_INTERVAL)


if __name__ == "__main__":
    host    = sys.argv[1] if len(sys.argv) > 1 else "localhost"
    payload = sys.argv[2] if len(sys.argv) > 2 else "ping"
    send_with_reconnect(host, payload)
